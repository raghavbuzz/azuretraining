<#	
	Version:        1.0
	Author:         Ahmad Majeed Zahoory
	Creation Date:  14th August, 2020
	Purpose/Change: Build PR & DR Environment

#>

############################################ PR Virtual Network ######################################################

# Variables for common values
$resourceGroup1 = "Az-303-07-01-RG1"
$location1= "eastus"

# Definer user name and password
$cred = Get-Credential -Message "Enter a username and password for the virtual machine."

# Create a resource group
New-AzresourceGroup -Name $resourceGroup1 -location $location1

# Create a virtual network with subnet
$subnet1 = New-AzVirtualNetworkSubnetConfig -Name WebSubnet -AddressPrefix 192.168.0.0/24
$subnet2 = New-AzVirtualNetworkSubnetConfig -Name DBSubnet -AddressPrefix 192.168.1.0/24
$vnet1 = New-AzVirtualNetwork -resourceGroupName $resourceGroup1 -Name PR-VNeT -AddressPrefix 192.168.0.0/23 `
  -location $location1 -Subnet $subnet1, $subnet2

############################################ DR Virtual Network ######################################################

# Variables for common values
$resourceGroup2 = "Az-303-07-01-RG2"
$location2 = "eastus2"

# Create a resource group
New-AzresourceGroup -Name $resourceGroup2 -location $location2

# Create a virtual network with subnet
$subnet1 = New-AzVirtualNetworkSubnetConfig -Name WebSubnet -AddressPrefix 192.168.0.0/24
$subnet2 = New-AzVirtualNetworkSubnetConfig -Name DBSubnet -AddressPrefix 192.168.1.0/24
$vnet2 = New-AzVirtualNetwork -resourceGroupName $resourceGroup2 -Name DR-VNeT -AddressPrefix 192.168.0.0/23 `
  -location $location2 -Subnet $subnet1, $subnet2

############################################ Public IP Address for Web DR Server ######################################################

# Create a public IP address and specify a DNS name
$pip3 = New-AzPublicIpAddress -ResourceGroupName $resourceGroup2 -Location $location2 `
  -Name "drwebsrvdns$(Get-Random)" -AllocationMethod Dynamic -IdleTimeoutInMinutes 4
  

############################################ PR Caching Storage ######################################################

$SkuName = "Standard_LRS"
$Prefix = "LAB303PR"

#Create Storageaccount
function New-RandomName {
( -join ((48..57) + (65..90) + (97..122) | Get-Random -Count 10 | % {[char]$_}))
}
do {
        $SARandomName = New-RandomName
        $SAName = ($Prefix + $SARandomName).ToLower()
        $Availability = Get-AzStorageAccountNameAvailability -Name $SAName
    }
while ($Availability.NameAvailable -eq $false)
    
New-AzStorageAccount -resourceGroupName $resourceGroup1 -Name $SAName -location $location1 -SkuName $SkuName

############################################ DR Caching Storage ######################################################

$SkuName = "Standard_LRS"
$Prefix = "LAB303DR"

#Create Storageaccount
function New-RandomName {
( -join ((48..57) + (65..90) + (97..122) | Get-Random -Count 10 | % {[char]$_}))
}
do {
        $SARandomName = New-RandomName
        $SAName = ($Prefix + $SARandomName).ToLower()
        $Availability = Get-AzStorageAccountNameAvailability -Name $SAName
    }
while ($Availability.NameAvailable -eq $false)
    
New-AzStorageAccount -resourceGroupName $resourceGroup2 -Name $SAName -location $location2 -SkuName $SkuName

############################################ Ubuntu Web Server ######################################################

# Create a public IP address and specify a DNS name
$pip1 = New-AzPublicIpAddress -resourceGroupName $resourceGroup1 -location $location1 -Name "websrvdns$(Get-Random)" -AllocationMethod Dynamic -IdleTimeoutInMinutes 4

# Create an inbound network security group rule for port 22, 80 
$nsgrule1 = New-AzNetworkSecurityRuleConfig -Name WebSrvNSGRule  -Protocol Tcp `
  -Direction Inbound -Priority 1000 -SourceAddressPrefix * -SourcePortRange * -DestinationAddressPrefix * `
  -DestinationPortRange "22", "80" -Access Allow

# Create a network security group
$nsg1 = New-AzNetworkSecurityGroup -resourceGroupName $resourceGroup1 -location $location1 `
  -Name webnsg -SecurityRules $nsgrule1
  
# Create a nic for vm
$nicvm1 = New-AzNetworkInterface -resourceGroupName $resourceGroup1 -location $location1 -Name 'nicvm1' -SubnetId $vnet1.Subnets[0].Id -PublicIpAddressId $pip1.Id -NetworkSecurityGroupId $nsg1.Id

# Create a virtual machine configuration
$vmConfig1 = New-AzVMConfig -VMName Web-SRV -VMSize Standard_DS1_v2 | `
Set-AzVMOperatingSystem -Linux -ComputerName Web-SRV -Credential $cred | `
Set-AzVMSourceImage -PublisherName Canonical -Offer UbuntuServer -Skus 18.04-LTS -Version 18.04.201910080 | `
Add-AzVMNetworkInterface -Id $nicvm1.Id

# Create a virtual machine
New-AzVM -resourceGroupName $resourceGroup1 -location $location1 -VM $vmConfig1

# Start a CustomScript extension to use a simple bash script to update, download and install Website Code 
$PublicSettings1 = '{"fileUris":["https://raw.githubusercontent.com/ahmadzahoory/az303/master/az-303-11-01-script-a.sh"],"commandToExecute":"sh az-303-11-01-script-a.sh"}'
Set-AzVMExtension -ExtensionName "AzBCP" -ResourceGroupName $resourceGroup1 -VMName Web-SRV `
  -Publisher "Microsoft.Azure.Extensions" -ExtensionType "CustomScript" -TypeHandlerVersion 2.0 `
  -SettingString $PublicSettings1 `
  -Location $location1
  
############################################ Ubuntu MySQL Server ######################################################

# Create a public IP address and specify a DNS name
$pip2 = New-AzPublicIpAddress -resourceGroupName $resourceGroup1 -location $location1 -Name "dbsrvdns$(Get-Random)" -AllocationMethod Dynamic -IdleTimeoutInMinutes 4

# Create an inbound network security group rule for port 22, 3306
$nsgrule2 = New-AzNetworkSecurityRuleConfig -Name DBSrvNSGRule  -Protocol Tcp `
  -Direction Inbound -Priority 1000 -SourceAddressPrefix * -SourcePortRange * -DestinationAddressPrefix * `
  -DestinationPortRange "22", "3306" -Access Allow

# Create a network security group
$nsg2 = New-AzNetworkSecurityGroup -resourceGroupName $resourceGroup1 -location $location1 `
  -Name dbnsg -SecurityRules $nsgrule2
  
# Create a nic for vm
$nicvm2 = New-AzNetworkInterface -resourceGroupName $resourceGroup1 -location $location1 -Name 'nicvm2' -SubnetId $vnet1.Subnets[1].Id -PublicIpAddressId $pip2.Id -NetworkSecurityGroupId $nsg2.Id

# Create a virtual machine configuration
$vmConfig2 = New-AzVMConfig -VMName DB-SRV -VMSize Standard_DS1_v2 | `
Set-AzVMOperatingSystem -Linux -ComputerName DB-SRV -Credential $cred | `
Set-AzVMSourceImage -PublisherName Canonical -Offer UbuntuServer -Skus 18.04-LTS -Version 18.04.201910080 | `
Add-AzVMNetworkInterface -Id $nicvm2.Id

# Create a virtual machine
New-AzVM -resourceGroupName $resourceGroup1 -location $location1 -VM $vmConfig2

# Start a CustomScript extension to use a simple bash script to update, download and install Website Code 
$PublicSettings2 = '{"fileUris":["https://raw.githubusercontent.com/ahmadzahoory/az303/master/az-303-11-01-script-b.sh"],"commandToExecute":"sh az-303-11-01-script-b.sh"}'
Set-AzVMExtension -ExtensionName "AzBCP" -ResourceGroupName $resourceGroup1 -VMName DB-SRV `
  -Publisher "Microsoft.Azure.Extensions" -ExtensionType "CustomScript" -TypeHandlerVersion 2.0 `
  -SettingString $PublicSettings2 `
  -Location $location1

#End